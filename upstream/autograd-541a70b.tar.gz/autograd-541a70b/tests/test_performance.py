# TODO:
# Do a huge calculation with trivial primitive computations
# and lots of diamonds and get a benchmark per-node time and
# memory cost.
